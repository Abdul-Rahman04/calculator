import React from "react";

import Cal from "./components/cal";
import "./App.css";

function App() {
  return <Cal />;
}

export default App;
